
<!DOCTYPE HTML>
<html>
<head>
        <link rel="shortcut icon" href="img/fav6icon.ico" type="image/x-icon" />
<title>Pixelr : Login</title>
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<!-- for-mobile-apps -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta name="keywords" content="Classy Login form Responsive, Login form web template, Sign up Web Templates, Flat Web Templates, Login signup Responsive web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<!-- //for-mobile-apps -->
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Roboto+Condensed:400,700' rel='stylesheet' type='text/css'>
</head>
<body>
<!--header start here-->
<div class="header">
		<div class="header-main">
		       <h1>Sign-Up</h1>
			<div class="header-bottom">
				<div class="header-right w3agile">
					
					<div class="header-left-bottom agileinfo">
						
					<form method="POST" action="q3.php">
                                             <input type="text"  value="first name" name="fname" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'first name';}"/>
                                             <input type="text"  value="last name" name="lname" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'last name';}"/>
                                             <input type="email"  value="email" name="email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'email';}"/	>
                                             <input type="text"  value="Age" name="age" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'age';}"/>
                                             <input type="tel" pattern="^\d{10}$" value="contact" name="contact" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'contact';}"/>                    
                                             
					<input type="password"  value="Password" name="password" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'password';}"/>
                                        
						
					   
						<input type="submit" name="signup" value="Sign-Up"><br> <br> 
                                                <input type="reset" value="reset">
					</form>	
					
					
						
				</div>
				</div>
			  
			</div>
		</div>
</div>

<!--footer end here-->
</body>
</html>

