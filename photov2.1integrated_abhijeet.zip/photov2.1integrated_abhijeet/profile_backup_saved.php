<?php
session_start();
 $con=mysqli_connect('localhost','root','Jigyasha') or die();
                            $db=mysqli_select_db($con,'pixlr') or die();
 // You can set the value however you like.
echo $id = $_SESSION['new_id'];
?>


 <!DOCTYPE html>
<html lang="en">
 <!--**************************************     HEAD     ***************************-->
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="shortcut icon" href="img/fav6icon.ico" type="image/x-icon" />
    <title>Pixelr : Profile </title>
    
    <!-- Font Awesome -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="css/indigo.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/material.min.css">
    <link rel="stylesheet" href="css/material.css">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">

    <!-- Template styles -->
    <style rel="stylesheet">
     
        .map{
          background-color: black; 
          position: relative; 
          top: -120px;
          width: 200px;
          height: 200px;
         
          border-style: none;
          border-radius: 100%;
          margin: 0 auto;
 
      }
        
        
        .mdl-card__actions > .mdl-button--icon {
	margin-right: 3px;
	margin-left: 3px;
}
 
        .navbar1 {
            background-color: #424242;
            
        }
        
      
        
        @media only screen and (max-width: 768px) {
            .navbar {
                background-color:#424242;
            }
        }
        main {
            margin-top: 3rem;
        }
        
        main .card {
            margin-bottom: 2rem;
        }
        
        @media only screen and (max-width: 768px) {
            .read-more {
                text-align: center;
            }
        }
    </style>

    
    
</head>

<body>
    
    
    <!--**************************************  HEADER  ***************************-->
    <header >
        <!--Navbar-->
        <nav class="navbar elegant-color-dark">

            <!-- Collapse button-->
            <button class="navbar-toggler hidden-sm-up" type="button" data-toggle="collapse" data-target="#collapseEx">
            <i class="fa fa-bars"></i>
        </button>

            <div class="container" >

                <!--Collapse content-->
                <div class="collapse navbar-toggleable-xs" id="collapseEx">
                    <!--Navbar Brand-->
                    <a class="navbar-brand" href="#" >Pixelr</a>
                    <!--Links--> <ul class="nav navbar-nav">
                  
                    <li class="nav-item active">
                        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
              
                     
                    <li class="nav-item">
                        <a class="nav-link" href="#">About</a>
                    </li>  
                     <?php
                        if(isset($_SESSION['new_id'])) {
                         //header("Location: /"); // redirects them to homepage
                         // exit; // for good measure
                    echo('
                    <li class="nav-item">
                        <a class="nav-link" href=" logout.php">Log out</a>
                    </li>
                   ');
                         

                         }?>                               
                    </ul>
                    <!--Search form-->
                    
                    <form class="form-inline">
                        <input class="form-control" type="text" placeholder="Search" >
                    </form>
                    <div   >
                     <img  id=tt1 style="padding-left: 5px;padding-top : 7px ;outline: none;" width="32px" height="32px" src="ic_account_circle_white_48dp/ic_account_circle_white_48dp/web/ic_account_circle_white_48dp_1x.png" class="img-fluid" alt="">
                     </div>
                        <div class="mdl-tooltip" data-mdl-for="tt1">Profile</div>
                   
                <!--/.Collapse content-->

            </div>

        </nav>
 
    
        
        <!--/.Navbar-->
    </header>
    
    <!-- *************************************  PROFILE   *************************** -->
    <div class="container">
                <hr>
        
                <div class="col-xl-8" style="align-items: center; width: 100%;"  >
                    <div class="card" style=" padding : 8px;height: auto; width : 100%; ">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                       



                            <?php

                              

                              $sql = "SELECT * FROM member WHERE mem_id = '$id'";
                              $sth = mysqli_query($con,$sql);
                              $result=mysqli_fetch_array($sth);
                              echo '<img src="data:image/jpeg;base64,'.base64_encode( $result['cover_image'] ).'" class="img-fluid" alt="" style="width:100%;height : auto;"/>'
                            ?>



                            <!--<img src="http://mdbootstrap.com/images/regular/people/img%20(6).jpg" class="img-fluid" alt="">-->
                            
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->
                    </div>
                    <div id="profilepic" class="card" style="  background-color: white;position: relative;top: -120px;width: 200px; height: 200px; border-radius: 100%;margin: 0 auto;">
                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                       

                            <?php

                              

                              $sql = "SELECT * FROM member WHERE mem_id = '$id'";
                              $sth = mysqli_query($con,$sql);
                              $result=mysqli_fetch_array($sth);
                              echo '<img src="data:image/jpeg;base64,'.base64_encode( $result['profile_image'] ).'" class="img-fluid" alt=""style="width: 200px; height: 200px; border-radius: 100%;padding: 8px;"/>'
                            ?>
                            <!--<img  src="http://mdbootstrap.com/images/regular/people/img%20(2).jpg" class="img-fluid" alt="" style="width: 200px; height: 200px; border-radius: 100%;padding: 8px;">-->
                            
                            <a href="#!">
                                <div class="mask" style="border-radius : 100%;"></div>
                            </a>
                        </div>
                    
                    </div>
                </div>
                
               <hr> 
               
              
            </div> 
            
    <div  class="mdl-tabs mdl-js-tabs  ">

    <div class="mdl-tabs__tab-bar mdl-js-ripple-effect">
        <a href="#tab1" class="mdl-tabs__tab">Images</a>
        <a href="#tab2" class="mdl-tabs__tab">Settings</a>
    </div>
  

    <div class="mdl-tabs__panel is-active" id="tab1">
        
        <main>
        <!--Main layout-->
        <div class="container">
             <button type="button" class="btn btn-elegant"  data-toggle="modal" data-target="#myModal" >Upload Image</button>   
            
<!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <!--Content-->
                                <div class="modal-content">
                            <!--Header-->
                             <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                             <span aria-hidden="true">&times;</span>
                            </button>
                                 <h4 class="modal-title" id="myModalLabel" style="position:absolute;text-align: center;">Add Image</h4>
                            </div>
                            <!--Body-->
                            <div class="modal-body">
                             <form method="POST" action="q3.php" enctype="multipart/form-data">
                                 <input type="file" name="myimage">
                            <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                <input class="mdl-textfield__input" name = "title" type="text" id="title" placeholder="Title"/>
                            
                            </div>
                            
                            
                            <div class="container">
                            <div class="row">
     
     <div class="button-group">
         <button type="button" class="btn btn-elegant btn-sm dropdown-toggle" data-toggle="dropdown"><span>Category</span> <span class="caret"></span></button>
<ul class="dropdown-menu">
    <li><div  class="large" data-value="option1" tabIndex="-1"><input type="checkbox"/>&nbsp;Nature</div></li>
    <li><div href="#"  data-value="option2" tabIndex="-1"><input type="checkbox"/>&nbsp;Animals</div></li>
    <li><div href="#"  data-value="option3" tabIndex="-1"><input type="checkbox"/>&nbsp;Plants</div></li>
    <li><div href="#"  data-value="option4" tabIndex="-1"><input type="checkbox"/>&nbsp;Wildlife</div></li>
    <li><div href="#"  data-value="option5" tabIndex="-1"><input type="checkbox"/>&nbsp;People</div></li>
    <li><div href="#"  data-value="option6" tabIndex="-1"><input type="checkbox"/>&nbsp;City</div></li>
</ul>
  </div>

  </div>
</div>
                            <br>
                            <input type="submit" style="background-color: #212121;color:white;" name="submit_image" value="Upload">
                            </form>
                            </div>
                             <!--Footer-->
                            <div class="modal-footer">
                            <button type="button" class="btn btn-elegant" data-dismiss="modal">Close</button>
                            
                            </div>
                        </div>
                        <!--/.Content-->
                           </div>   
                       </div>

            
           
            
              <!--  
            <form method="POST" action="getdata.php" enctype="multipart/form-data">
            <input type="file" name="myimage">
            <input type="submit" name="submit_image" value="Upload">
            </form> -->

                
      
            <hr>

            <!--First row-->
            <div class="row">
                <!--First column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">
                    
                        <!--Card image-->
                             <div class="view overlay hm-white-slight">
                            <a href="#!" id="pop">
                                <div class="mask"></div>
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              $sql = "SELECT * FROM image WHERE mem_id='$id' ";

                              $result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              $img_id=$row['img_id'];
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg
                              
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            </a>
                          
                            <div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                                        <h4 class="modal-title" id="myModalLabel">Image preview</h4>
                                    </div>
                                    <div class="modal-body">
                                        <img src="" id="imagepreview" style="width: 400px; height: 264px;" >
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>  
                            </div>

                            
                            
                            
                            
                        </div>
                        
                        
                                                <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                    
                        </div>
                        
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.First column-->

                <!--Second column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                           <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id' AND img_id >= '$cnt'";
                              //$cnt=$cnt+1;
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);


                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            <!--Text-->
                            
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.Second column-->

                <!--Third column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                            <a href="#!" id="pop1">
                                <div class="mask"></div>
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                              $image_t=$row['path'];
                                echo "<img src='".$image_t."' class='img-fluid' alt=''>";
                            ?>
                            </a>
                          
                            <div class="modal fade" id="imagemodal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                                        <h4 class="modal-title" id="myModalLabel1">Image preview</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card">

                        <!--Card image-->
                                    <div class="view overlay hm-white-slight">
                                        
                                   <?php
                                echo "<img src='".$image_t."' class='img-fluid' alt=''>";
                                   ?>
                            
                                     <a href="#!">
                                        <div class="mask"></div>
                                     </a>
                                        </div>
                        <!--/.Card image-->
                        
                        <hr>
                       
                        
                                        </div>
                                        
                                          <div class="card">
                                        <div class="card-block">
                                         <form action="#">
                                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                            <input class="mdl-textfield__input" type="text" placeholder="comment">
                                            
			 
                                        </div>
                                             <button type="button" class="btn btn-elegant" style="position: absolute;top: 40px;right:10px;" >Post</button>
                                         </form>
                                               
                                        </div>
                                                                               
                                    </div>
                                        
                                    </div>
                                  
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-elegant" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>  
                            </div>

                            
                            
                            
                            
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            
                            <!--Text-->
                            
                        </div>
                          
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.Third column-->
            </div>
            <!--/.First row-->

            <!--Second row-->
            <div class="row">
                <!--First column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                       
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.First column-->

                <!--Second column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                             // $sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                      
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--Second column-->

                <!--Third column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            <!--Text-->
                           
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.Third column-->
            </div>
            <!--/.Second row-->
            <hr>

            <!--Pagination-->
            <nav class="row text-xs-center">
                <ul class="pagination">
                    <li class="page-item disabled">
                        <a class="page-link" href="#!" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                            <span class="sr-only">Previous</span>
                        </a>
                    </li>
                    <li class="page-item active">
                        <a class="page-link" href="#!">1 <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#!">2</a></li>
                    <li class="page-item"><a class="page-link" href="#!">3</a></li>
                    <li class="page-item"><a class="page-link" href="#!">4</a></li>
                    <li class="page-item"><a class="page-link" href="#!">5</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#!" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                            <span class="sr-only">Next</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <!--/.Pagination-->
            <hr>
        </div>
        <!--/.Main layout-->
    </main>

    </div>
    <div class="mdl-tabs__panel" id="tab2">
             <main>
                 <div class="container">
        <div class="card">
            <div class="container">
        <button type="button" class="btn btn-elegant"  data-toggle="modal" data-target="#myModal1" >Profile Pic</button>   
            
<!-- Modal -->
                        <div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <!--Content-->
                                <div class="modal-content">
                            <!--Header-->
                             <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                             <span aria-hidden="true">&times;</span>
                            </button>
                                 <h4 class="modal-title" id="myModalLabel" style="position:absolute;text-align: center;">Add Image</h4>
                            </div>
                            <!--Body-->
                            <div class="modal-body">
                             <form method="POST" action="q3.php" enctype="multipart/form-data">
                            <input type="file" name="myimage">
                            <input type="submit" name="submit_image_profile" value="Upload">
                            </form>
                            </div>
                             <!--Footer-->
                            <div class="modal-footer">
                            <button type="button" class="btn btn-elegant" data-dismiss="modal">Close</button>
                            
                            </div>
                        </div>
                        <!--/.Content-->
                           </div>   
                       </div>

        <br>
        <button type="button" class="btn btn-elegant"  data-toggle="modal" data-target="#myModal2" >Cover Image</button>   
            
<!-- Modal -->
                        <div class="modal fade" id="myModal2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <!--Content-->
                                <div class="modal-content">
                            <!--Header-->
                             <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                             <span aria-hidden="true">&times;</span>
                            </button>
                                 <h4 class="modal-title" id="myModalLabel" style="position:absolute;text-align: center;">Add Image</h4>
                            </div>
                            <!--Body-->
                            <div class="modal-body">
                             <form method="POST" action="q3.php" enctype="multipart/form-data">
                            <input type="file" name="myimage">
                            <input type="submit" name="submit_image_cover" value="Upload">
                            </form>
                            </div>
                             <!--Footer-->
                            <div class="modal-footer">
                            <button type="button" class="btn btn-elegant" data-dismiss="modal">Close</button>
                            
                            </div>
                        </div>
                        <!--/.Content-->
                           </div>   
                       </div>
        <br>
        <button type="button" class="btn btn-elegant"  data-toggle="modal" data-target="#myModal3" >Change Password</button>   
            
<!-- Modal -->
                        <div class="modal fade" id="myModal3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <!--Content-->
                                <div class="modal-content">
                            <!--Header-->
                             <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                             <span aria-hidden="true">&times;</span>
                            </button>
                                 <h4 class="modal-title" id="myModalLabel" style="position:absolute;text-align: center;">Enter New Password</h4>
                            </div>
                            <!--Body-->
                            <div class="modal-body">
                             <form method="POST" action="q3.php" enctype="multipart/form-data">
                                 <input type="password" name="password" placeholder="Enter New Password">
                            <input type="submit" name="submit_new_password" value="Submit">
                            </form>
                            </div>
                             <!--Footer-->
                            <div class="modal-footer">
                            <button type="button" class="btn btn-elegant" data-dismiss="modal">Close</button>
                            
                            </div>
                        </div>
                        <!--/.Content-->
                           </div>   
                       </div>
        
    </div>
    </div>
                 </div>
                 </main>
    </div>
    </div>
   <div class="mdl-layout-spacer"></div>
   
    <!--/.Footer-->
    <footer   class="mdl-mega-footer elegant-color-dark"  >
    <div class="mdl-mega-footer--middle-section">

        <div class="mdl-mega-footer--drop-down-section">
            <input class="mdl-mega-footer--heading-checkbox" type="checkbox" checked>
            <h1 class="mdl-mega-footer--heading">About</h1>
        </div>

        <div class="mdl-mega-footer--drop-down-section">
            <input class="mdl-mega-footer--heading-checkbox" type="checkbox" checked>
            <h1 class="mdl-mega-footer--heading">Team</h1>
            
        </div>

        <div class="mdl-mega-footer--drop-down-section">
            <input class="mdl-mega-footer--heading-checkbox" type="checkbox" checked>
            <h1 class="mdl-mega-footer--heading">Contact</h1>
            
        </div>
    </div>
        </footer>
    
    
    
    <!-- SCRIPTS -->

    <!-- JQuery -->
    
    <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>

    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/tether.min.js"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
    <script src="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.min.js"></script>
    <script src="https://code.getmdl.io/1.2.1/material.min.js"></script>
    <script>
    $("#pop1").on("click", function() {
      var php_var = "<?php echo $img_id; ?>";
      window.alert("<?php echo $img_id; ?>");

   $('#imagepreview1').attr('src', $('#imageresource1').attr('src')); // here asign the image to the modal when the user click the enlarge link
    // here asign the image to the modal when the user click the enlarge link
        $('#imagemodal1').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
});

      $("#pop").on("click", function() {
   $('#imagepreview').attr('src', $('#imageresource').attr('src')); // here asign the image to the modal when the user click the enlarge link
    // here asign the image to the modal when the user click the enlarge link
        $('#imagemodal').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
});
    
    
    $("#profile").click(function(){
        $("#tabb3").click();
    });
    
    
    var options = [];

$( '.dropdown-menu a' ).on( 'click', function( event ) {

   var $target = $( event.currentTarget ),
       val = $target.attr( 'data-value' ),
       $inp = $target.find( 'input' ),
       idx;

   if ( ( idx = options.indexOf( val ) ) > -1 ) {
      options.splice( idx, 1 );
      setTimeout( function() { $inp.prop( 'checked', false ) }, 0);
   } else {
      options.push( val );
      setTimeout( function() { $inp.prop( 'checked', true ) }, 0);
   }

   $( event.target ).blur();
      
   console.log( options );
   return false;
});
    
    </script>
   
    </div>
</body>

</html>