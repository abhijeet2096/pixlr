<?php
session_start();
 $con=mysqli_connect('localhost','root','Jigyasha') or die();
                            $db=mysqli_select_db($con,'pixlr') or die();

 $id = $_SESSION['new_id'];
?>

<!DOCTYPE html>
<html lang="en">
 <!--**************************************     HEAD     ***************************-->
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <link rel="shortcut icon" href="img/fav6icon.ico" type="image/x-icon" />
    <title>Pixelr : Home </title>
    
    <!-- Font Awesome -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="css/indigo.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/material.min.css">
    <link rel="stylesheet" href="css/material.css">
     <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">

    <!-- Template styles -->
    <style rel="stylesheet">
     
        .map{
          background-color: black; 
          position: relative; 
          top: -120px;
          width: 200px;
          height: 200px;
         
          border-style: none;
          border-radius: 100%;
          margin: 0 auto;
 
      }
        
        
        .mdl-card__actions > .mdl-button--icon {
	margin-right: 3px;
	margin-left: 3px;
}
 
        .navbar1 {
            background-color: #424242;
            
        }
        
      
        
        @media only screen and (max-width: 768px) {
            .navbar {
                background-color:#424242;
            }
        }
        main {
            margin-top: 3rem;
        }
        
        main .card {
            margin-bottom: 2rem;
        }
        
        @media only screen and (max-width: 768px) {
            .read-more {
                text-align: center;
            }
        }
    </style>

    
    
</head>

<body>
    
    
    <!--**************************************  HEADER  ***************************-->
    <header >
        <!--Navbar-->
        <nav class="navbar elegant-color-dark">

            <!-- Collapse button-->
            <button class="navbar-toggler hidden-sm-up" type="button" data-toggle="collapse" data-target="#collapseEx">
            <i class="fa fa-bars"></i>
        </button>

            <div class="container" >

                <!--Collapse content-->
                <div class="collapse navbar-toggleable-xs" id="collapseEx">
                    <!--Navbar Brand-->
                    <a class="navbar-brand" href="#" >Pixelr</a>
                    <!--Links--> <ul class="nav navbar-nav">
                  
                    <li class="nav-item active">
                     <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                    </li>
              
                     

                    <li class="nav-item">
                        <a class="nav-link" href="#">About</a>
                    </li>

                    <?php
                        if(isset($_SESSION['new_id'])) {
                         //header("Location: /"); // redirects them to homepage
                         // exit; // for good measure
                    echo('
                    <li class="nav-item">
                        <a class="nav-link" href=" logout.php">Log out</a>
                    </li>
                   ');
                         

                         }
                         else
                         {   echo('
                    <li class="nav-item">
                        <a class="nav-link" href="signin.php">Login</a>
                    </li>
                     <li class="nav-item">
                         <a class="nav-link" href="signup.php">SignUp</a>
                    </li> ');}
                     
                    ?>
                        
                       
                  
                    </ul>
                    <!--Search form-->
                    
                    <form class="form-inline">
                        <input class="form-control" type="text" placeholder="Search" >
                    </form>
                    <a href="profile.php"  >

                    
                     <?php

                              $sql = "SELECT * FROM member WHERE mem_id = '$id'";
                              $sth = mysqli_query($con,$sql);
                              $result=mysqli_fetch_array($sth);

                    
                     echo'<img  id=tt1 style="padding-left: 5px;padding-top : 7px ;outline: none;" width="32px"  height="32px" src="data:image/jpeg;base64,'.base64_encode( $result['profile_image'] ).'"  class="img-circle" alt="">';
                    
                     ?>
                     </a>
                        <div class="mdl-tooltip" data-mdl-for="tt1">Profile</div>
                   
                <!--/.Collapse content-->

            </div>

        </nav>
 
    
        
        <!--/.Navbar-->
    </header>
    <div  class="mdl-tabs mdl-js-tabs  ">

    <div class="mdl-tabs__tab-bar mdl-js-ripple-effect">
        <a href="#tab1" class="mdl-tabs__tab">Explore</a>
        <a href="#tab2" class="mdl-tabs__tab">Gallery</a>
        <!--<a href="#tab3" class="mdl-tabs__tab">
            <div id = "tabb3">Profile</div></a>-->
    </div>
  

    <div class="mdl-tabs__panel is-active" id="tab1">
        
        <main>
        <!--Main layout-->
        <div class="container">

      
            <hr>
              <?php
              $counter =0;
              $sql = "SELECT * FROM image ORDER BY img_id DESC";

                              $result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              //$row = mysqli_fetch_assoc($result);
              while($row = mysqli_fetch_array($result))
              {$title=$row['title'];
              $caption=$row['caption'];
              $img_id=$row['img_id'];
                $img_id_temp = "#pop".$img_id;
                $img_id_preview= "#preview".$img_id;
                $img_id_with= "#".$img_id;
                 
                $img_id_temp_1 = "pop".$img_id;
                $img_id_preview_1= "preview".$img_id;
                $img_id_with_1= $img_id;

                  if($counter%3==0)
                  {
                    echo'<div class="container-fluid">';
                    echo'<div class="row">';
                  }
                 echo'

                 
                 <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">';

                          

                        echo"
                             <a href='#!' id='".$img_id_temp_1."'>";
                                echo'<div class="mask"></div>';
                         
                              //$row = mysqli_fetch_assoc($result);
                              $image_t=$row['path'];
                                echo "<img src='".$image_t."' class='img-fluid' alt=''></a>";
                           echo'
                            <div class="modal fade" id="mod'.$img_id.'" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                                        <h4 class="modal-title" id="myModalLabel1">';
                                                        echo $title;
                                                         echo'</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card">

                        <!--Card image-->
                                    <div class="view overlay hm-white-slight">
                                        
                                   ';
                               echo "<img src='".$image_t."' class='img-fluid' alt=''>";
                                  
                                  echo'
                                     <a href="#!">
                                        <div class="mask"></div>
                                     </a>
                                        </div>
                        <!--/.Card image-->
                        
                        <hr>
                       
                        
                                        </div>
                                        
                                          <div class="card">
                                        <div class="card-block">
                                        <form action="q3.php?img_id='.$img_id.'&comment_id='.$comment_id_close.'" method="POST">
                                                                    <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                                                        <input class="mdl-textfield__input" name="my_comment" type="text" placeholder="your comment">


                                                                    </div>
                                                                    <button name="post_comment" class="btn btn-elegant" style="position: absolute;top: 40px;right:10px;" >Post comment</button>
                                                                </form>
                                               
                                        </div>
                                                                               
                                    </div>
                                        
                                    </div>';//var[i]=img_id;i++;

                                                        //$ _SESSION['img_id'] = $img_id_comment;

                                      
                                                         $con2=mysqli_connect('localhost','root','Jigyasha') or die();
                                                                    $db2=mysqli_select_db($con2,'pixlr') or die();
                                                        
                                                        //echo $img_id;
                                                         $query = "SELECT * FROM r_comment WHERE img_id= " .$img_id. " ORDER BY comment_id DESC";
                                                        $res = mysqli_query($con2, $query);
                                                        if($res){
                                                        while($row = mysqli_fetch_array($res)){
                                                           // printf("heloo");
                                                        echo '<div class="card">';
                                                        echo '<div class="card-block">';
                                                        $mem_id = $row['mem_id'];
                                                        $q = "SELECT * FROM member WHERE mem_id = '$mem_id'";
                                                        $r = mysqli_query($con2,$q);
                                                        $row1 = mysqli_fetch_array($r);
                                                        

                                                        echo '<div>';
                                                        echo '<img src="data:image/jpeg;base64,'.base64_encode( $row1['profile_image'] ).'" class="img-fluid" alt=""style="width: 50px; height: 50px; border-radius: 100%;padding: 8px;"/>';
                                                        echo $row1['fname'];
                                                        echo ' ';
                                                         echo $row1['lname'];
                                                         $comment_id_close=$row["comment_id"];
                                                         echo'<form action="q3.php?comment_id='.$comment_id_close.'" method="POST">';
                                                         echo '<button name="delete_comment" class="close" aria-label="Close">';
                                                         echo '</form>';
                                                         echo'
                                                        <span aria-hidden="true">&times;</span>
                                                              </button>';
                                                        
                                                         echo '</div>';

                                                        
                                                        echo '<br>';
                                                        printf ("\n%s",$row["comment"]);
                                                        echo '</div>';
                                                        echo '</div>';
                                                        }
                                                        }
                                                        mysqli_close($con2);
                                     echo'




                                    <div class="modal-footer">
                                    
                                    </div>
                                </div>
                            </div>  
                            </div>  

                            
                            
                            
                            
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">';
                            echo $title;
                            echo'</h4>
                            
                            <!--Text-->
                            
                        </div>
                          
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>

                <!--/.Third column-->
          ';
          $counter=$counter+1;
          if($counter%3==0){
           echo' </div>';
           //echo' </div>';
         }


              echo'<script>

                          
              
                          $("#'.$img_id_temp_1.'").click(function(){
                            
                              img_id=$(this).attr("id");
                              $("#imagepreview1").attr("src", $("#imageresource1").attr("src")); 
                              $("#mod'.$img_id.'").modal("show"); 
                          });
                        </script>';
          }





         
         if($counter%3!=0)
           echo' </div>';
          ?>
 

            
            <hr>

            <!--Pagination-->
            <nav class="row text-xs-center">
                <ul class="pagination">
                    <li class="page-item disabled">
                        <a class="page-link" href="#!" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                            <span class="sr-only">Previous</span>
                        </a>
                    </li>
                    <li class="page-item active">
                        <a class="page-link" href="#!">1 <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#!">2</a></li>
                    <li class="page-item"><a class="page-link" href="#!">3</a></li>
                    <li class="page-item"><a class="page-link" href="#!">4</a></li>
                    <li class="page-item"><a class="page-link" href="#!">5</a></li>
                    <li class="page-item">
                        <a class="page-link" href="#!" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                            <span class="sr-only">Next</span>
                        </a>
                    </li>
                </ul>
            </nav>
            <!--/.Pagination-->
            <hr>
        </div>
        <!--/.Main layout-->
    </main>

    </div>
    <div class="mdl-tabs__panel" id="tab2">
              
        <div class="row">
                <!--First column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">
                    
                        <!--Card image-->
                             <div class="view overlay hm-white-slight">
                            <a href="#!" id="pop">
                                <div class="mask"></div>
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              $sql = "SELECT * FROM image  ";

                              $result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              $img_id=$row['img_id'];
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg
                              
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            </a>
                          
                            <div class="modal fade" id="imagemodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                                        <h4 class="modal-title" id="myModalLabel">Image preview</h4>
                                    </div>
                                    <div class="modal-body">
                                        <img src="" id="imagepreview" style="width: 400px; height: 264px;" >
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>  
                            </div>

                            
                            
                            
                            
                        </div>
                        
                        
                                                <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                    
                        </div>
                        
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.First column-->

                <!--Second column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                           <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id' AND img_id >= '$cnt'";
                              //$cnt=$cnt+1;
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);


                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            <!--Text-->
                            
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.Second column-->

                <!--Third column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                            <a href="#!" id="pop1">
                                <div class="mask"></div>
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                              $image_t=$row['path'];
                                echo "<img src='".$image_t."' class='img-fluid' alt=''>";
                            ?>
                            </a>
                          
                            <div class="modal fade" id="imagemodal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                                        <h4 class="modal-title" id="myModalLabel1">Image preview</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="card">

                        <!--Card image-->
                                    <div class="view overlay hm-white-slight">
                                        
                                   <?php
                                echo "<img src='".$image_t."' class='img-fluid' alt=''>";
                                   ?>
                            
                                     <a href="#!">
                                        <div class="mask"></div>
                                     </a>
                                        </div>
                        <!--/.Card image-->
                        
                        <hr>
                       
                        
                                        </div>
                                        
                                          <div class="card">
                                        <div class="card-block">
                                         <form action="#">
                                        <div class="mdl-textfield mdl-js-textfield mdl-textfield--floating-label">
                                            <input class="mdl-textfield__input" type="text" placeholder="comment">
                                            
       
                                        </div>
                                             <button type="button" class="btn btn-elegant" style="position: absolute;top: 40px;right:10px;" >Post</button>
                                         </form>
                                               
                                        </div>
                                                                               
                                    </div>
                                        
                                    </div>
                                  
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-elegant" data-dismiss="modal">Close</button>
                                    </div>
                                </div>
                            </div>  
                            </div>

                            
                            
                            
                            
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            
                            <!--Text-->
                            
                        </div>
                          
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.Third column-->
            </div>
            <!--/.First row-->

            <!--Second row-->
            <div class="row">
                <!--First column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                       
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.First column-->

                <!--Second column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                             // $sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                      
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--Second column-->

                <!--Third column-->
                <div class="col-md-4">
                    <!--Card-->
                    <div class="card">

                        <!--Card image-->
                        <div class="view overlay hm-white-slight">
                            <?php

                              
                              // do some validation here to ensure id is safe
                               

                              //$sql = "SELECT * FROM image WHERE mem_id='$id'";
                              //$result = mysqli_query($con,$sql) or die(mysqli_error($db));
                              $row = mysqli_fetch_assoc($result);
                              //mysql_close($con);
                              //echo "abhijeet";
                               //header("Content-type: image/jpeg

                              //$imgpath=$row['path'];
                                echo "<img src='".$row['path']."' class='img-fluid' alt=''>";
                            ?>
                            <a href="#!">
                                <div class="mask"></div>
                            </a>
                        </div>
                        <!--/.Card image-->

                        <!--Card content-->
                        <div class="card-block">
                            <!--Title-->
                            <h4 class="card-title">Card title</h4>
                            <!--Text-->
                           
                        </div>
                        <!--/.Card content-->

                    </div>
                    <!--/.Card-->
                </div>
                <!--/.Third column-->
            </div>
            <!--/.Second row-->
    </div>
        
    
   
    </div>

    
   <div class="mdl-layout-spacer"></div>
   
    <!--/.Footer-->
    <footer   class="mdl-mega-footer elegant-color-dark"  >
    <div class="mdl-mega-footer--middle-section">

        <div class="mdl-mega-footer--drop-down-section">
            <input class="mdl-mega-footer--heading-checkbox" type="checkbox" checked>
            <h1 class="mdl-mega-footer--heading">About</h1>
        </div>

        <div class="mdl-mega-footer--drop-down-section">
            <input class="mdl-mega-footer--heading-checkbox" type="checkbox" checked>
            <h1 class="mdl-mega-footer--heading">Team</h1>
            
        </div>

        <div class="mdl-mega-footer--drop-down-section">
            <input class="mdl-mega-footer--heading-checkbox" type="checkbox" checked>
            <h1 class="mdl-mega-footer--heading">Contact</h1>
            
        </div>
    </div>
        </footer>
    
    
    
    <!-- SCRIPTS -->

    <!-- JQuery -->
    
    <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>

    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/tether.min.js"></script>

    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>

    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script defer src="https://code.getmdl.io/1.2.1/material.min.js"></script>
    <script src="https://storage.googleapis.com/code.getmdl.io/1.0.0/material.min.js"></script>
    <script src="https://code.getmdl.io/1.2.1/material.min.js"></script>
    <script>
    $("#pop1").on("click", function() {
   $('#imagepreview1').attr('src', $('#imageresource1').attr('src')); // here asign the image to the modal when the user click the enlarge link
    // here asign the image to the modal when the user click the enlarge link
        $('#imagemodal1').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
});

      $("#pop").on("click", function() {
   $('#imagepreview').attr('src', $('#imageresource').attr('src')); // here asign the image to the modal when the user click the enlarge link
    // here asign the image to the modal when the user click the enlarge link
        $('#imagemodal').modal('show'); // imagemodal is the id attribute assigned to the bootstrap modal, then i use the show function
});
    
    
    $("#profile").click(function(){
        $("#tabb3").click();
    });
    </script>
   
    </div>
</body>

</html>