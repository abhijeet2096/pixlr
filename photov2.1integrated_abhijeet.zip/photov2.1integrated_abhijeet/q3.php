<?php

/*if(!isset($_SESSION['new_id'])) {
   include_once("signin.php");
   exit;
}
*/
session_start();
 // You can set the value however you like.
?>

<html>
<head>
</head>
<body>

	<?php


//global $email;

//echo "Hello";

	function SignUp()
	{
		echo "In signup";

		$con=mysqli_connect('localhost','root','Jigyasha') or die("Failed to connect to SQL DB: ");
		$db=mysqli_select_db($con,'pixlr') or die("Failed to connect to SQL DB: ");

$fname=$_POST['fname'];    //starting the session for user profile page
$lname=$_POST['lname'];
$email=$_POST['email']; 
$age=$_POST['age'];    //starting the session for user profile page
$contact=$_POST['contact'];
$password=$_POST['password'];

$query = mysqli_query($con,"SELECT * FROM member") or die('Invalid query: '. mysqli_error());
while($row = mysqli_fetch_array($query))
{
	$id = $row['mem_id'];
        //echo $id;
}
$id = $id + 1;
mysqli_query($con,"INSERT INTO member VALUES('$id','$fname','$email','$age','','','$password','$lname','$contact')");

$_SESSION['new_id'] = $id;

//echo $_SESSION['new_id'];
//echo mysql_error($con);

header("location: home.php");
    //echo $row = mysqli_fetch_array($query)  

}

function SignIn()
{
	$con=mysqli_connect('localhost','root','Jigyasha') or die("Failed to connect to SQL DB: ");
	$db=mysqli_select_db($con,"pixlr") or die("Failed to connect to SQL DB: ");

$email=$_POST['email'];    //starting the session for user profile page
$password=$_POST['password'];

$query = mysqli_query($con,"SELECT *  FROM `member` where email = '$email'");
	echo $row = mysqli_fetch_array($query) ;//or die("Details not found Invalid");

	if(!empty($row))
	{
        //echo $row["password"];

		if($row["password"]==$password)
		{
			$_SESSION['new_id'] = $row["mem_id"];	
			header("location: home.php"); 
			die();
		}
		else
		{
			echo "blah";
			header("location: signin.php"); 
			die();
		}


	}
	else
	{
        //echo $email;
        //echo $row["password"];
		echo "blah-blah";
		header("location: signup.php"); 
		die();
	}
}



function Upload()
{
	echo $title = $_POST['title'];
	echo "Inupload";
    //session_start();
	$mem_id = $_SESSION['new_id'];

    //echo "dadfds".$id;

    //$con=mysqli_connect('localhost','root','Jigyasha') or die("Failed to connect to SQL DB: ");
    //$db=mysqli_select_db($con,'pixlr') or die("Failed to connect to SQL DB: ");

	$imagename=$_FILES['myimage']['name']; 
   // echo $imagename;

//Get the content of the image and then add slashes to it 
	$imagetmp=addslashes(file_get_contents($_FILES['myimage']['tmp_name']));

//Insert the image name and image content in image_table
//!empty($imagename);
	if (1)
	{
		echo "abhijeet";
		$imgtype=$_FILES["myimage"]["type"];
        //echo $ext= GetImageExtension($imgtype);
		echo $ext = ".jpeg";
		$imagename=date("d-m-Y")."-".time().$ext;
		echo $target_path = "/Pixlr/photo/images/".$imagename;

		if(move_uploaded_file($_FILES['myimage']['tmp_name'],'/var/www/html/Pixlr/photo/images/'.$imagename)) {

			echo "abhijeet";
			$con=mysqli_connect('localhost','root','Jigyasha') or die();
			$db=mysqli_select_db($con,'pixlr') or die();

			$date = date('Y-m-d H:i:s');

			$sql = "SELECT * FROM image";
			$rdata = mysqli_query($con,$sql);
			while($res=mysqli_fetch_array($rdata))
			{
				$id = $res['img_id'];
				echo $id;
			}
			$id = $id+1;
    //echo $id;
			$query=mysqli_query($con,"INSERT INTO image VALUES ('$id','$title','wq','$date',12,'$mem_id',12,'".$target_path."')");
        //echo $imagename;
        header("Location: profile.php");
    //mysql_query($query) or die();  //"error in $query == ----> ".mysql_error()

		}else{

			exit("Error While uploading image on the server");
		} 

	}

//header("location: display.php");
}

function Upload_Blob_profile(){
	$id = $_SESSION['new_id'];
    //echo "dadfds".$id;

	$con=mysqli_connect('localhost','root','Jigyasha') or die("Failed to connect to SQL DB: ");
	$db=mysqli_select_db($con,'pixlr') or die("Failed to connect to SQL DB: ");

	$imagename=$_FILES['myimage']['name']; 
	echo $imagename;

//Get the content of the image and then add slashes to it 
	$imagetmp=addslashes(file_get_contents($_FILES['myimage']['tmp_name']));

//Insert the image name and image content in image_table
	$new_id = $id;
	$update_image="UPDATE member SET profile_image ='$imagetmp' WHERE mem_id ='$id'" ;
	mysqli_query($con,$update_image);

	header("location: profile.php");
}
function Upload_Blob_cover(){
	$id = $_SESSION['new_id'];
    //echo "dadfds".$id;

	$con=mysqli_connect('localhost','root','Jigyasha') or die("Failed to connect to SQL DB: ");
	$db=mysqli_select_db($con,'pixlr') or die("Failed to connect to SQL DB: ");

	$imagename=$_FILES['myimage']['name']; 
	echo $imagename;

//Get the content of the image and then add slashes to it 
	$imagetmp=addslashes(file_get_contents($_FILES['myimage']['tmp_name']));

//Insert the image name and image content in image_table
	$new_id = $id;
	$update_image="UPDATE member SET cover_image ='$imagetmp' WHERE mem_id ='$id'" ;
	mysqli_query($con,$update_image);

	header("location: profile.php");
}

function change_password()
{
	echo $id = $_SESSION['new_id'];
    //echo "dadfds".$id;
	echo $newpassword=$_POST['password'];

	$con=mysqli_connect('localhost','root','Jigyasha') or die("Failed to connect to SQL DB: ");
	$db=mysqli_select_db($con,'pixlr') or die("Failed to connect to SQL DB: ");

    //$imagename=$_FILES['myimage']['name']; 
    //echo $imagename;

//Get the content of the image and then add slashes to it 
//$imagetmp=addslashes(file_get_contents($_FILES['myimage']['tmp_name']));

//Insert the image name and image content in image_table
//$new_id = $id;
	$update_password="UPDATE member SET password  ='$newpassword' WHERE mem_id ='$id'" ;
	mysqli_query($con,$update_password); 
	header("location: profile.php");
}



if(isset($_POST['signup']))
{
	echo "here";
	SignUp();
}
if(isset($_POST['Login']))
{
	SignIn();
}
//echo "hello down";

if(isset($_POST['submit_image']))
{
	echo "in upload buton ";
	Upload();
}

if(isset($_POST['submit_image_profile']))
{
	echo "in upload buton ";
	Upload_Blob_profile();
}
if(isset($_POST['submit_image_cover']))
{
	echo "in upload buton ";
	Upload_Blob_cover();
}
if(isset($_POST['submit_new_password']))
{
	echo "in password";
	change_password();
}


?>
</body>
</html>
